﻿using CandidateAssessment.Models;
using CandidateAssessment.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Diagnostics;

namespace CandidateAssessment.Controllers
{
    public class RecordsController : Controller
    {

        private CandidateAssessmentContext _dbContext;
        private StudentService _studentService;
        private SchoolService _schoolService;
        private OrganizationsService _organizationsService;

        public RecordsController(StudentService studentService, CandidateAssessmentContext dbContext, SchoolService schoolService, OrganizationsService organizationsService)
        {
            _studentService = studentService;
            _schoolService = schoolService;
            _organizationsService = organizationsService;
            _dbContext = dbContext;
        }

        public IActionResult Students()
        {
            ViewBag.AgeList = CreateAgeList();
            ViewBag.SchoolList = CreateSchoolDropdownList();
            ViewBag.OrgList = CreateStudentOrgDropdown();

            var model = _studentService.GetStudents().OrderBy(s => s.LastName);
            return View(model);
        }

        public IActionResult Schools()
        {
            var model = _schoolService.GetSchools().OrderBy(s => s.Name);
            return View(model);
        }

        public IActionResult StudentOrganization()
        {
            var model = _organizationsService.GetOrganizations().OrderBy(s => s.OrgName);
            return View(model);
        }

        [HttpGet]
        [Route("Records/GetEnrolles/{schoolid:int}")]
        public IActionResult GetEnrolles(int schoolid)
        {
            var model = _studentService.GetStudents().Where(s => s.SchoolId == schoolid);
            return View(model);
        }

        [HttpPost]
        public IActionResult SaveStudent(Student model)
        {
            // replace this code with code that actually saves the model
            //lets ge the values and assign to variables from model

            var selectedOrgIds = model.SelectedOrgs;

            ///Lets just try just one ID
            var studentOrgs = new List<int>();
            studentOrgs.Add(4);

            ////lets loop through data set and add ids
            //foreach (var orgId in selectedOrgIds)
            //{
            //    studentOrgs.Add(new StudentOrganizationt
            //    {
            //        orgId
            //    }) ;

            //}

            Student stdtable = new Student();

            stdtable.FirstName = model.FirstName;
            stdtable.LastName = model.LastName;
            stdtable.Email = model.Email;
            stdtable.Age = model.Age;
            stdtable.SchoolId = model.SchoolId;

            ///I couldnt get the list id to even populate to even test so i made it work sorry did givr it eh old college try
            stdtable.OrgAssignments = model.OrgAssignments;

            _dbContext.Add(stdtable);
            _dbContext.SaveChanges();



            //using (var context = new StudentService())
            //{
            //    // Attach an entity to DbContext with Added state
            //    context.Add<Student>(std);

            //    // Calling SaveChanges to insert a new record into Students table
            //    context.SaveChanges();
            //}




            return RedirectToAction("Students");
        }

        private List<SelectListItem> CreateAgeList()
        {
            var ageList = new List<SelectListItem>();
            for (int i = 18; i < 100; i++)
            {
                ageList.Add(new SelectListItem
                {
                    Text = i.ToString(),
                    Value = i.ToString()
                });
            }
            return ageList;
        }

        private List<SelectListItem> CreateSchoolDropdownList()
        {
            var schoolList = new List<SelectListItem>();

            //lets get all the scools
            var schoolmodel = _schoolService.GetSchools().OrderBy(s => s.Name);

            //lets loop through data set and add new one 
            foreach (var school in schoolmodel)
            {
                schoolList.Add(new SelectListItem
                {
                    Text = @school.Name,
                    Value = @school.SchoolId.ToString()
                });
            }


            return schoolList;

            // replace this code with code to grab the schools and create a List<SelectListItem> object from them.
             //return new List<SelectListItem> {
             //    new SelectListItem { Text = "Replace this code 2", Value = "" }
             //};
        }

        private MultiSelectList CreateStudentOrgDropdown()
        {
            //lets get data and throw in object 
            var studentorgs = _organizationsService.GetOrganizations().OrderBy(s => s.OrgName);

            //new list
            var items = new List<SelectListItem>();

            //lets loop through the object earlier to get data and value
            foreach (var org in studentorgs)
            {
                var item = new SelectListItem
                {
                    Value = org.Id.ToString(),
                    Text = org.OrgName
                };

                ///money adds item tot he array
                items.Add(item);
            }

            // replace this code with code to grab the student orgs and create a List<SelectListItem> object from them.
            //var options = new List<SelectListItem>
            //{
            //    new SelectListItem { Text = "Option 1", Value = "1" },
            //    new SelectListItem { Text = "Option 2", Value = "2" },
            //    new SelectListItem { Text = "Option 3", Value = "3" },
            //    new SelectListItem { Text = "Option 4", Value = "4" }
            //};

            return new MultiSelectList(items, "Value", "Text");
        }
    }
}