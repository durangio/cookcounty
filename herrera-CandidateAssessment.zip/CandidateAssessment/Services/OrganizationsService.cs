﻿using CandidateAssessment.Models;
using Microsoft.EntityFrameworkCore;

namespace CandidateAssessment.Services
{
    public class OrganizationsService
    {
        private CandidateAssessmentContext _dbContext;

        public OrganizationsService(CandidateAssessmentContext dbContext)
        {
            _dbContext = dbContext;

        }
        public IEnumerable<StudentOrganization> GetOrganizations()
        {
            return _dbContext.StudentOrganizations
                .Include(s => s.OrgAssignments);
        }
    }
}

